package DAO;

import DAO.DBConnection;
import Modelo.Inventarios;
import Modelo.Proveedores;
import Modelo.Proveedores;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class ProveedoresDAO {

    DAO.DBConnection conn;

    public ProveedoresDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Proveedores proveedores) {
        try {
            String sql = "insert into proveedores values (?,?,?,?,?,?);";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, proveedores.getId());
            ps.setString(2, proveedores.getNombre());
            ps.setString(3, proveedores.getTipo());
            ps.setString(4, proveedores.getEncargado());
            ps.setString(5, proveedores.getTelefono());
            ps.setString(6, proveedores.getRubro());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede registrar " + e);
        }
        return false;
    }

    public List<Proveedores> consultar() {
        try {

            String sql = "select * from proveedores";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Proveedores> lista = new LinkedList();
            Proveedores proveedores;
            while (rs.next()) {
                proveedores = new Proveedores(rs.getInt("id"));
                proveedores.setNombre(rs.getString("nombre"));
                proveedores.setTipo(rs.getString("tipo"));
                proveedores.setEncargado(rs.getString("encargado"));
                proveedores.setTelefono(rs.getString("telefono"));
                proveedores.setRubro(rs.getString("rubro"));
                lista.add(proveedores);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return null;
    }
    
    
    public List<Proveedores> ConsultarPorCod_Autor(int id) {
        String sql = "select * from editoriales where id = ?";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            List<Proveedores> lista = new LinkedList<>();
            Proveedores proveedores;
            while (rs.next()) {
                proveedores = new Proveedores(rs.getInt("id"));
                proveedores.setNombre(rs.getString("nombre"));
                proveedores.setTipo(rs.getString("tipo"));
                proveedores.setEncargado(rs.getString("encargado"));
                proveedores.setTelefono(rs.getString("telefono"));
                proveedores.setRubro(rs.getString("rubro"));
                lista.add(proveedores);
            }
            System.out.println("consulta realizada correctamente" + lista);
            return lista;
        } catch (Exception e) {
            System.out.println("Error en consulta por codigo en proveedorDAO. " + e.getMessage());
            return null;
        }
    }

    public boolean eliminar(int id) {
        try {
            String sql = "delete from proveedores where id = ?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);
            int row = ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Se ha eliminado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede eliminar registro" + e);
        }
        return false;
    }

    public boolean actualizar(Proveedores proveedores) {
        try {
            String sql = "update proveedores set "
                    + "id_proveedor=?,"
                    + "id_libro=?,"
                    + "estado=?,"
                    + "existencias=?,"
                    + "stock_minimo=?"
                    + "where id=?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, proveedores.getId());
            ps.setString(2, proveedores.getNombre());
            ps.setString(3,proveedores.getTipo());
            ps.setString(4, proveedores.getEncargado());
            ps.setString(5, proveedores.getTelefono());
            ps.setString(6, proveedores.getRubro());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Actualizado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede actualizar" + e);

        }
        return false;
    }

}
