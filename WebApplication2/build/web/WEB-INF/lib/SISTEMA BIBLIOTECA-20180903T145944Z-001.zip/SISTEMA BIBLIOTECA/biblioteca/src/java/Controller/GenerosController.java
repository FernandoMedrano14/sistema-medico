/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DBConnection;
import DAO.GenerosDAO;
import Modelo.Generos;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class GenerosController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {

            String action = request.getParameter("action");
            switch (action) {
                case "ingresar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;
                case "consultarporID":
                    this.consultarporID(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error en controller action" + e);

        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String genero = request.getParameter("genero");

            Generos generos = new Generos(0);
            generos.setGenero(genero);

            DBConnection conn = new DBConnection();
            GenerosDAO dao = new GenerosDAO(conn);
            String mensaje;
            boolean respuesta = dao.registrar(generos);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/insertargenero.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error registro controller: " + e);
        }

    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            GenerosDAO dao = new GenerosDAO(conn);
            List<Generos> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultargenero.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error consulta controller: " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id_autor = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            GenerosDAO dao = new GenerosDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id_autor));
            List<Generos> lista = dao.consultar();
            String mensaje = "";

            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";

            }
            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultargenero.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error eliminar controller: " + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String mensaje = "";
        String id = request.getParameter("id");
        String genero = request.getParameter("genero");
        try {

            DBConnection conn = new DBConnection();
            GenerosDAO dao = new GenerosDAO(conn);
            Generos generos = new Generos(0);
            List<Generos> lista = dao.consultar();

            generos.setGenero(genero);
            generos.setId(Integer.parseInt(id));

            boolean respuesta = dao.actualizar(generos);
            if (respuesta) {
                mensaje = "Se actualizó con exito";
            }

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/consultargenero.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            mensaje = "Error al actualizar en controller" + e;
        }

    }

    protected void consultarporID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            GenerosDAO dao = new GenerosDAO(conn);
            List<Generos> lista = dao.ConsultarPorCod_Autor(Integer.parseInt(id));

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/modificargenero.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error al consultar en controller" + e);
        }
    }
}
