package DAO;

import Modelo.Inventarios;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class InventariosDAO {

    DBConnection conn;

    public InventariosDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Inventarios inventarios) {
        try {
            String sql = "insert into inventarios values (?,?,?,?,?,?);";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, inventarios.getId());
            ps.setInt(2, inventarios.getId_proveedor());
            ps.setInt(3, inventarios.getId_libro());
            ps.setString(4, inventarios.getEstado());
            ps.setInt(5, inventarios.getExistencias());
            ps.setInt(6, inventarios.getStock_minimo());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede registrar" + e);
        }
        return false;
    }

    public List<Inventarios> consultar() {
        try {

            String sql = "select * from inventarios;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Inventarios> lista = new LinkedList();
            Inventarios inventarios;
            while (rs.next()) {
                inventarios = new Inventarios(rs.getInt("id"));
                inventarios.setId_proveedor(rs.getInt("id_proveedor"));
                inventarios.setId_libro(rs.getInt("id_libro"));
                inventarios.setEstado(rs.getString("estado"));
                inventarios.setExistencias(rs.getInt("existencias"));
                inventarios.setStock_minimo(rs.getInt("stock_minimo"));
                lista.add(inventarios);
                return lista;
            }
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return null;
    }
    
        
        public List<Inventarios> ConsultarPorCod_Autor(int id){
    String sql = "select * from inventarios where id = ?;";
    try {
        PreparedStatement ps = conn.Conectar().prepareStatement(sql);
        ps.setInt(1, id);
        
        ResultSet rs = ps.executeQuery();
        List<Inventarios> lista = new LinkedList<>();
        Inventarios inventario;
        while(rs.next()){
        inventario = new Inventarios (rs.getInt("id"));
        inventario.setId_proveedor(rs.getInt("id_proveedor"));
        inventario.setId_libro(rs.getInt("id_libro"));
        inventario.setEstado(rs.getString("estado"));
        inventario.setExistencias(rs.getInt("existencias"));
        inventario.setStock_minimo(rs.getInt("stock_minimo"));
        lista.add(inventario);
        }
        System.out.println("consulta realizada correctamente"+ lista);
        return lista;
    } catch (Exception e) {
        System.out.println("Error en consulta por codigo en AutorDAO. "+e.getMessage());
        return null;
    }
}

    public boolean eliminar(int id) {
        try {
            String sql = "delete from inventarios where id = ?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);
            int row = ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Se ha eliminado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede eliminar registro");
        }
        return false;
    }

    public boolean actualizar(Inventarios inventarios) {
        try {
            String sql = "update inventarios set "
                    + "id_proveedor=?,"
                    + "id_libro=?,"
                    + "estado=?,"
                    + "existencias=?,"
                    + "stock_minimo=?"
                    + "where id=?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, inventarios.getId_proveedor());
            ps.setInt(2, inventarios.getId_libro());
            ps.setString(3, inventarios.getEstado());
            ps.setInt(4, inventarios.getExistencias());
            ps.setInt(5, inventarios.getStock_minimo());
            ps.setInt(6, inventarios.getId());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Actualizado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede actualizar");

        }
        return false;
    }

}


