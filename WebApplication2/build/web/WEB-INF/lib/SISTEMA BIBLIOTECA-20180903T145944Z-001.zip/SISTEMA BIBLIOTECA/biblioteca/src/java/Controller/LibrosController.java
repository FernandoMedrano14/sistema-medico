/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DBConnection;
import DAO.LibrosDAO;
import Modelo.Libros;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class LibrosController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try {

            String accion = request.getParameter("action");
            switch (accion) {
                case "registrar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {

        }
    }
    
    @Override
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int id_editorial = Integer.parseInt(request.getParameter("id_editorial"));
            int id_genero = Integer.parseInt(request.getParameter("id_genero"));
            String nombre = request.getParameter("nombre");
            String fecha_publicacion = request.getParameter("fecha_publicacion");
            int tomo = Integer.parseInt(request.getParameter("tomo"));
            String edicion = request.getParameter("edicion");
            int paginas = Integer.parseInt(request.getParameter("paginas"));
            String estado = request.getParameter("estado");

            Libros libros = new Libros(0);
            libros.setId_editorial(id_editorial);
            libros.setId_genero(id_genero);
            libros.setNombre(nombre);
            libros.setFecha_publicacion(fecha_publicacion);
            libros.setTomo(tomo);
            libros.setEdicion(edicion);
            libros.setPaginas(paginas);
            libros.setEstado(estado);

            DBConnection conn = new DBConnection();
            LibrosDAO dao = new LibrosDAO(conn);
            String mensaje;
            boolean respuesta = dao.registrar(libros);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            rd = request.getRequestDispatcher("/insertarlibro.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error en registro controller" + e);
        }
    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            LibrosDAO dao = new LibrosDAO(conn);
            List<Libros> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarlibro.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id_libro = request.getParameter("id_libro");

        try {
            DBConnection conn = new DBConnection();
            LibrosDAO dao = new LibrosDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id_libro));
            List<Libros> lista = dao.consultar();
            String mensaje = "";

            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";

            }
            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consulta.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String mensaje = "";
        try {
            DBConnection conn = new DBConnection();

            LibrosDAO dao = new LibrosDAO(conn);
            Libros libros = new Libros(0);
            List<Libros> lista = dao.consultar();

            libros.setId_editorial(Integer.parseInt(request.getParameter("id_editorial")));
            libros.setId_genero(Integer.parseInt(request.getParameter("id_genero")));
            libros.setNombre(request.getParameter("id_proveedor"));
            libros.setFecha_publicacion(request.getParameter("fecha_publicacion"));
            libros.setTomo(Integer.parseInt(request.getParameter("tomo")));
            libros.setEdicion(request.getParameter("edicion"));
            libros.setPaginas(Integer.parseInt(request.getParameter("paginas")));
            libros.setEstado(request.getParameter("estado"));
            libros.setId_libro(Integer.parseInt("id_libro"));

            boolean respuesta = dao.actualizar(libros);
            if (respuesta) {
                mensaje = "Se actualizó con exito";
            }

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/consultarlibro.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            mensaje = "Error al actualizar" + e;
        }

    }

    protected void consultarporID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id_libro = request.getParameter("id_libro");

        try {
            DBConnection conn = new DBConnection();
            LibrosDAO dao = new LibrosDAO(conn);
            List<Libros> lista = dao.ConsultarPorCod_Autor(Integer.parseInt(id_libro));

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/modificarlibro.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error en controller" + e);
        }
    }

}
