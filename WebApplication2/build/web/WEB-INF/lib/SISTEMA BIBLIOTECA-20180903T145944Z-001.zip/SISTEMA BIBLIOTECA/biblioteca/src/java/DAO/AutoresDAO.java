package DAO;

import Modelo.Autores;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class AutoresDAO {

    DBConnection conn;

    public AutoresDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Autores autores) {
        try {
            String sql = "insert into autores values (?,?,?,?)";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, autores.getId_autor());
            ps.setString(2, autores.getNombre());
            ps.setString(3, autores.getFecha_nacimiento());
            ps.setString(4, autores.getNacionalidad());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se pudo registrar " + e);
        }
        return false;
    }

    public List<Autores> consultar() {
        try {
            String sql = "select * from autores;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Autores> lista = new LinkedList<>();
            Autores autores;

            while (rs.next()) {
                autores = new Autores(rs.getInt("id_autor"));
                autores.setNombre(rs.getString("nombre"));
                autores.setFecha_nacimiento(rs.getString("fecha_nacimiento"));
                autores.setNacionalidad(rs.getString("nacionalidad"));
                lista.add(autores);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("No se puede acceder al registro");
        }
        return null;
    }
    
    public List<Autores> ConsultarPorCod_Autor(int id_autor){
    String sql = "select * from autores where id_autor = ?";
    try {
        PreparedStatement ps = conn.Conectar().prepareStatement(sql);
        ps.setInt(1, id_autor);
        
        ResultSet rs = ps.executeQuery();
        List<Autores> lista = new LinkedList<>();
        Autores autor;
        while(rs.next()){
        autor = new Autores (rs.getInt("id_autor"));
        autor.setNombre(rs.getString("nombre"));
        autor.setFecha_nacimiento(rs.getString("fecha_nacimiento"));
        autor.setNacionalidad(rs.getString("nacionalidad"));
        lista.add(autor);
        }
        System.out.println("consulta realizada correctamente"+ lista);
        return lista;
    } catch (Exception e) {
        System.out.println("Error en consulta por codigo en AutorDAO. "+e.getMessage());
        return null;
    }
}

    public boolean eliminar(int id_autor) {

        try {
            String sql = "delete from autores where id_autor=?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id_autor);
            int row = ps.executeUpdate();
            System.out.println("Eliminado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede eliminar" + e);
        }
        return false;
    }

    public boolean actualizar(Autores autores) {
        String sql = "update autores set nombre=?, fecha_nacimiento=?, nacionalidad=? where id_autor=?; ";
        try {

            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setString(1, autores.getNombre());
            ps.setString(2, autores.getFecha_nacimiento());
            ps.setString(3, autores.getNacionalidad());
            ps.setInt(4, autores.getId_autor());
            ps.executeUpdate();
            System.out.println("Actualizado");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede actualizar en AutoresDAO: " + e);
            return false;
        }
    }

}
