
package Modelo;


public class Inventarios {
    
    private int id;
    private int id_proveedor;
    private int id_libro;
    private String estado;
    private int existencias;
    private int stock_minimo;

    public Inventarios(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public int getId_libro() {
        return id_libro;
    }

    public void setId_libro(int id_libro) {
        this.id_libro = id_libro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getExistencias() {
        return existencias;
    }

    public void setExistencias(int existencias) {
        this.existencias = existencias;
    }

    public int getStock_minimo() {
        return stock_minimo;
    }

    public void setStock_minimo(int stock_minimo) {
        this.stock_minimo = stock_minimo;
    }

    @Override
    public String toString() {
        return "Inventarios{" + "id=" + id + ", id_proveedor=" + id_proveedor + ", id_libro=" + id_libro + ", estado=" + estado + ", existencias=" + existencias + ", stock_minimo=" + stock_minimo + '}';
    }
    
    
    
}
