
package Modelo;

public class Libro {
    
    private int id_libro;
    private int id_editorial;
    private int id_genero;
    private String nombre;
    private String fecha_publicacion;
    private int tomo;
    private String edicion;
    private int paginas;
    private String estado;

    public Libro(int id_libro) {
        this.id_libro = id_libro;
    }

    public int getId_libro() {
        return id_libro;
    }

    public void setId_libro(int id_libro) {
        this.id_libro = id_libro;
    }

    public int getId_editorial() {
        return id_editorial;
    }

    public void setId_editorial(int id_editorial) {
        this.id_editorial = id_editorial;
    }

    public int getId_genero() {
        return id_genero;
    }

    public void setId_genero(int id_genero) {
        this.id_genero = id_genero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFecha_publicacion() {
        return fecha_publicacion;
    }

    public void setFecha_publicacion(String fecha_publicacion) {
        this.fecha_publicacion = fecha_publicacion;
    }

    public int getTomo() {
        return tomo;
    }

    public void setTomo(int tomo) {
        this.tomo = tomo;
    }

    public String getEdicion() {
        return edicion;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Libro{" + "id_libro=" + id_libro + ", id_editorial=" + id_editorial + ", id_genero=" + id_genero + ", nombre=" + nombre + ", fecha_publicacion=" + fecha_publicacion + ", tomo=" + tomo + ", edicion=" + edicion + ", paginas=" + paginas + ", estado=" + estado + '}';
    }
    
    
    
}
