package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import Modelo.Usuario;

/**
 *
 * @author Admin107
 */
public class UsuarioDAO {
    
    DBConnection conn;

    public UsuarioDAO(DBConnection conn) {
        this.conn = conn;
    }
    
     public boolean insert(Usuario usuario) {
        
        String sql = "insert into usuarios values(?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, usuario.getId());
            ps.setString(2, usuario.getUsuario());
            ps.setString(3, usuario.getCorreo());
            ps.setString(4, usuario.getContra());
            ps.setString(5,usuario.getGenero());
            ps.executeUpdate();
            System.out.println("registrado con exito");
            conn.Desconectar();
            return true;
        } catch (SQLException e) {
            System.out.println("error al ingresar datos usuario" + e);
            return false;
        }
        
    }
     
     public List<Usuario> Consultar() {
        
        String sql = "select * from usuarios ";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Usuario> lista = new LinkedList<>();
            Usuario usuario;
            while (rs.next()) {
                usuario = new Usuario(rs.getInt("id"));
                usuario.setUsuario(rs.getString("usuario"));
                usuario.setCorreo(rs.getString("correo"));
                usuario.setContra(rs.getString("contra"));
                usuario.setGenero(rs.getString("genero"));
                lista.add(usuario);
            }
            return lista;
            
        } catch (Exception e) {
            System.out.println("error" + e);
            return null;
        }
     }
     
      public boolean eliminar(int id) {
        
        String sql = "delete from usuario where id=?;";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            // conn.desconectar();
            return true;
        } catch (Exception e) {
            System.out.println("no se pudo eliminar registro");
        }
        return false;
      }
      
        public boolean actualizar(Usuario usuario) {
        String sql = " update usuarios set "
                + "usuario=?,"
                + "correo=?,"
                + "contra=?,"
                + "genero=? "
                + "where id=?";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setString(1, usuario.getUsuario());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getContra());
            ps.setString(4, usuario.getGenero());
            ps.setInt(5,usuario.getId());
            ps.executeUpdate();
            System.out.println("lista actualizada");
            return true;
        } catch (Exception e) {
            System.out.println("lista no actualizada" + e);
            return false;
        }
        }
        
        public Usuario consultarporID(int id) {
        try {
            String sql = "select * from usuarios where id=?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Usuario usu = new Usuario(rs.getInt("id"));
                usu.setUsuario(rs.getString("usuario"));
                usu.setCorreo(rs.getString("correo"));
                usu.setContra(rs.getString("contra"));
                usu.setGenero(rs.getString("genero"));
                return usu;
                
            } else {
                System.out.println("NO SE ENCONTRO NINGUN USUARIO. ");
                return null;
            }
            
        } catch (SQLException ex) {
            System.out.println("ERROR AL SELECCIONAR UN USUARIO POR ID. " + ex);
            return null;
        }
    }
    
    public List<Usuario> entrar(String usuario, String contra) {
        try {
            String sql = "select * from usuarios where usuario=? and contra=?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contra);
            ResultSet rs = ps.executeQuery();
            List<Usuario> lista = new LinkedList<>();
            Usuario user;
            while (rs.next()) {
                user = new Usuario(rs.getInt("id"));
                user.setUsuario(rs.getString("usuario"));
                user.setCorreo(rs.getString("correo"));
                user.setContra(rs.getString("contra"));
                user.setGenero(rs.getString("genero"));
                lista.add(user);
            }
            return lista;
            
        } catch (SQLException ex) {
            System.out.println("ERROR AL ENTRAR " + ex);
            return null;
        }
    }
}

