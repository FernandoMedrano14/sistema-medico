package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    static String db = "biblioteca";
    static String user = "root";
    static String pass = "root";
    static String url = "jdbc:mysql://localhost/" + db;
    Connection conn = null;

    public DBConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, pass);
            if (conn != null) {
                System.out.println("Exito al conectar con: " + db);
            }
        } catch (Exception e) {
            System.out.println("Error" + e);

        }
    }

    public Connection Conectar() {

        return conn;
    }

    public void Desconectar() throws SQLException {

        conn.close();
    }

}
