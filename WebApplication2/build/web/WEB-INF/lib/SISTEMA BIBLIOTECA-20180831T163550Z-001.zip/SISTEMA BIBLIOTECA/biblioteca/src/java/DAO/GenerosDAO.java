package DAO;

import Modelo.Generos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class GenerosDAO {

    DBConnection conn;

    public GenerosDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Generos generos) {
        try {
            String sql = "insert into generos values (?,?);";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, generos.getId());
            ps.setString(2, generos.getGenero());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se ha registrado en DAO: " + e);
        }
        return false;
    }

    public List<Generos> consultar() {
        try {
            String sql = "select * from generos;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Generos> lista = new LinkedList();
            Generos generos;
            while (rs.next()) {
                generos = new Generos(rs.getInt("id"));
                generos.setGenero(rs.getString("genero"));
                lista.add(generos);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return null;
    }

    public List<Generos> ConsultarPorCod_Autor(int id) {
        String sql = "select * from generos where id= ?;";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            List<Generos> lista = new LinkedList<>();
            Generos generos;
            while (rs.next()) {
                generos = new Generos(rs.getInt("id"));
                generos.setGenero(rs.getString("genero"));
                lista.add(generos);
            }
            System.out.println("consulta realizada correctamente" + lista);
            return lista;
        } catch (Exception e) {
            System.out.println("Error en consulta por codigo en generosDAO. " + e.getMessage());
            return null;
        }
    }

    public boolean eliminar(int id) {
        try {
            String sql = "delete from generos where id=?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);
            int row = ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Eliminado");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede eliminar" + e);
        }
        return false;
    }

    public boolean actualizar(Generos generos) {
        try {
            String sql = "update generos set genero=? where id=?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setString(1, generos.getGenero());
            ps.setInt(2, generos.getId());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Actualizado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede actualizar en controller" + e);
            return false;
        }
    }
}
