/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DBConnection;
import DAO.InventariosDAO;
import Modelo.Inventarios;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class InventariosController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try {

            String action = request.getParameter("action");
            switch (action) {
                case "ingresar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;

                case "consultarporID":
                    this.consultarporID(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            System.out.println("error" + e);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.processRequest(request, response);
    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int id_proveedor = Integer.parseInt(request.getParameter("id_proveedor"));
            int id_libro = Integer.parseInt(request.getParameter("id_libro"));
            String estado = request.getParameter("estado");
            int existencias = Integer.parseInt(request.getParameter("existencias"));
            int stock_minimo = Integer.parseInt(request.getParameter("stock_minimo"));

            Inventarios inventarios = new Inventarios(0);
            inventarios.setId_proveedor(id_proveedor);
            inventarios.setId_libro(id_libro);
            inventarios.setEstado(estado);
            inventarios.setExistencias(existencias);
            inventarios.setStock_minimo(stock_minimo);

            DBConnection conn = new DBConnection();
            InventariosDAO dao = new InventariosDAO(conn);
            String mensaje;
            boolean respuesta = dao.registrar(inventarios);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/insertarinventarios.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error " + e);
        }

    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            InventariosDAO dao = new InventariosDAO(conn);
            List<Inventarios> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarinventario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            InventariosDAO dao = new InventariosDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id));
            List<Inventarios> lista = dao.consultar();
            String mensaje = "";

            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";

            }
            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarinventario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String mensaje = "";
        String id = request.getParameter("id");
        String id_proveedor = request.getParameter("id_proveedor");
        String id_libro = request.getParameter("id_libro");
        String estado = request.getParameter("estado");
        String existencias = request.getParameter("existencias");
        String stock_minimo = request.getParameter("stock_minimo");
        try {
            DBConnection conn = new DBConnection();
            InventariosDAO dao = new InventariosDAO(conn);
            Inventarios inventarios = new Inventarios(0);
            List<Inventarios> lista = dao.consultar();

            inventarios.setId_proveedor(Integer.parseInt(id_proveedor));
            inventarios.setId_libro(Integer.parseInt(id_libro));
            inventarios.setEstado(estado);
            inventarios.setExistencias(Integer.parseInt(existencias));
            inventarios.setStock_minimo(Integer.parseInt(stock_minimo));
            inventarios.setId(Integer.parseInt(id));

            boolean respuesta = dao.actualizar(inventarios);
            if (respuesta) {
                mensaje = "Se actualizó con exito";
            }
            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/consultarinventario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            mensaje = "Error controller" + e;
        }

    }

    protected void consultarporID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            InventariosDAO dao = new InventariosDAO(conn);
            List<Inventarios> lista = dao.ConsultarPorCod_Autor(Integer.parseInt(id));

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/modificarinventarios.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error en consulta por id " + e);
        }
    }

}
