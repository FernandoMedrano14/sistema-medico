/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DBConnection;
import DAO.InventariosDAO;
import DAO.ProveedoresDAO;
import Modelo.Proveedores;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class ProveedoresController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try {

            String action = request.getParameter("action");
            switch (action) {
                case "ingresar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;

                case "consultarporID":
                    this.consultarporID(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            System.out.println("error" + e);
        }
    }
    
      protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.processRequest(request, response);
    }
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.processRequest(request, response);
    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String nombre = request.getParameter("nombre");
            String tipo = request.getParameter("tipo");
            String encargado = request.getParameter("encargado");
            String telefono = request.getParameter("telefono");
            String rubro = request.getParameter("rubro");

            Proveedores proveedores = new Proveedores(0);
            proveedores.setNombre(nombre);
            proveedores.setTipo(tipo);
            proveedores.setEncargado(encargado);
            proveedores.setTelefono(telefono);
            proveedores.setRubro(rubro);

            DBConnection conn = new DBConnection();
            ProveedoresDAO dao = new ProveedoresDAO(conn);
            String mensaje;
            boolean respuesta = dao.registrar(proveedores);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            rd = request.getRequestDispatcher("/insertarproveedores.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error " + e);
        }
    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            ProveedoresDAO dao = new ProveedoresDAO(conn);
            List<Proveedores> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarproveedores.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            ProveedoresDAO dao = new ProveedoresDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id));
            List<Proveedores> lista = dao.consultar();
            String mensaje = "";

            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";

            }
            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarproveedores.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String mensaje = "";
        try {
            DBConnection conn = new DBConnection();

            ProveedoresDAO dao = new ProveedoresDAO(conn);
            Proveedores proveedores = new Proveedores(Integer.parseInt("id"));
            proveedores.setNombre(request.getParameter("nombre"));
            proveedores.setTipo(request.getParameter("tipo"));
            proveedores.setEncargado(request.getParameter(("encargado")));
            proveedores.setTelefono(request.getParameter("telefono"));
            proveedores.setRubro(request.getParameter("rubro"));

            if (dao.actualizar(proveedores)) {
                mensaje = "Se actualizó con exito";
            }
        } catch (Exception e) {
            mensaje = "Error al actualizar" + e;
        }

    }

    protected void consultarporID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            ProveedoresDAO dao = new ProveedoresDAO(conn);
            List<Proveedores> lista = dao.ConsultarPorCod_Autor(Integer.parseInt(id));

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/modificarproveedores.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error en consulta por id " + e);
        }
    }

    public String getServletInfo() {
        return "Short description";
    }

}
