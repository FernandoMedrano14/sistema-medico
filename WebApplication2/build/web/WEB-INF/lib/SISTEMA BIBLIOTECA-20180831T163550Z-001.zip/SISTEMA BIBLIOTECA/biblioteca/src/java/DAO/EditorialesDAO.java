package DAO;

import Modelo.Editoriales;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class EditorialesDAO {

    DBConnection conn;

    public EditorialesDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Editoriales editoriales) {
        try {
            String sql = "insert into editoriales values (?,?,?,?,?);";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, editoriales.getId());
            ps.setString(2, editoriales.getNombre());
            ps.setString(3, editoriales.getDireccion());
            ps.setString(4, editoriales.getPais());
            ps.setString(5, editoriales.getTelefono());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("error en DAO" + e);
        }
        return false;
    }

    public List<Editoriales> consultar() {
        try {
            String sql = "select * from editoriales";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Editoriales> lista = new LinkedList();
            Editoriales editoriales;

            while (rs.next()) {
                editoriales = new Editoriales(rs.getInt("id"));
                editoriales.setNombre(rs.getString("nombre"));
                editoriales.setDireccion(rs.getString("direccion"));
                editoriales.setPais(rs.getString("pais"));
                editoriales.setTelefono(rs.getString("telefono"));
                lista.add(editoriales);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("No se puede acceder al registro" + e);
        }
        return null;
    }

    public List<Editoriales> ConsultarPorCod_Autor(int id) {
        String sql = "select * from editoriales where id = ?";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            List<Editoriales> lista = new LinkedList<>();
            Editoriales editorial;
            while (rs.next()) {
                editorial = new Editoriales(rs.getInt("id"));
                editorial.setNombre(rs.getString("nombre"));
                editorial.setDireccion(rs.getString("direccion"));
                editorial.setPais(rs.getString("pais"));
                editorial.setTelefono(rs.getString("telefono"));
                lista.add(editorial);
            }
            System.out.println("consulta realizada correctamente" + lista);
            return lista;
        } catch (Exception e) {
            System.out.println("Error en consulta por codigo en AutorDAO. " + e.getMessage());
            return null;
        }
    }

    public boolean eliminar(int id) {

        try {
            String sql = "delete from editoriales where id=?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id);
            int row = ps.executeUpdate();
            System.out.println("Eliminado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede eliminar" + e);
        }
        return false;
    }

    public boolean actualizar(Editoriales editoriales) {
        try {
            String sql = "update editoriales set nombre=?, direccion=?, pais=?, telefono=? where id=?;";

            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setString(1, editoriales.getNombre());
            ps.setString(2, editoriales.getDireccion());
            ps.setString(3, editoriales.getPais());
            ps.setString(3, editoriales.getTelefono());
            ps.setInt(5, editoriales.getId());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Actualizado");
            return true;
        } catch (Exception e) {
            System.out.println("Error en DAO" + e);
        }
        return false;
    }

}
