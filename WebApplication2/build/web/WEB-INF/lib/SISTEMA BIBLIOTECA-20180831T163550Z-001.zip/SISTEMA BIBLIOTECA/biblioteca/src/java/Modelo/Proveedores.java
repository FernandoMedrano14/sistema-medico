
package Modelo;

public class Proveedores {
    
    private int id;
    private String nombre;
    private String tipo;
    private String encargado;
    private String telefono;
    private String rubro;

    public Proveedores(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEncargado() {
        return encargado;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getRubro() {
        return rubro;
    }

    public void setRubro(String rubro) {
        this.rubro = rubro;
    }

    @Override
    public String toString() {
        return "Proveedores{" + "id=" + id + ", nombre=" + nombre + ", tipo=" + tipo + ", encargado=" + encargado + ", telefono=" + telefono + ", rubro=" + rubro + '}';
    }
    
}
