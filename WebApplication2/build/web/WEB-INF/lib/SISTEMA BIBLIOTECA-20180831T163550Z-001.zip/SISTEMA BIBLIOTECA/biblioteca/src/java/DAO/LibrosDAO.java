package DAO;

import Modelo.Libros;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class LibrosDAO {

    DBConnection conn;

    public LibrosDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Libros libro) {
        String sql = "insert into libros values (?,?,?,?,?,?,?,?,?);";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, libro.getId_libro());
            ps.setInt(2, libro.getId_editorial());
            ps.setInt(3, libro.getId_genero());
            ps.setString(4, libro.getNombre());
            ps.setString(5, libro.getFecha_publicacion());
            ps.setInt(6, libro.getTomo());
            ps.setString(7, libro.getEdicion());
            ps.setInt(8, libro.getPaginas());
            ps.setString(9, libro.getEstado());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("Error en el registro" + e);
            return false;
        }

    }

    public List<Libros> consultar() {

        try {
            String sql = "select * from libros;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Libros> lista = new LinkedList();
            Libros libro;

            while (rs.next()) {
                libro = new Libros(rs.getInt("id_libro"));
                libro.setId_editorial(rs.getInt("id_editorial"));
                libro.setId_genero(rs.getInt("id_genero"));
                libro.setNombre(rs.getString("nombre"));
                libro.setFecha_publicacion(rs.getString("fecha_publicacion"));
                libro.setTomo(rs.getInt("tomo"));
                libro.setEdicion(rs.getString("edicion"));
                libro.setPaginas(rs.getInt("paginas"));
                libro.setEstado(rs.getString("estado"));
                lista.add(libro);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("No se pudo consultar");
        }

        return null;
    }

    public List<Libros> ConsultarPorCod_Autor(int id_libro) {
        String sql = "select * from libros where id_libro=?;";
        try {
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id_libro);

            ResultSet rs = ps.executeQuery();
            List<Libros> lista = new LinkedList<>();
            Libros libro;
            while (rs.next()) {
                libro = new Libros(rs.getInt("id_libro"));
                libro.setId_editorial(rs.getInt("id_editorial"));
                libro.setId_genero(rs.getInt("id_genero"));
                libro.setNombre(rs.getString("nombre"));
                libro.setFecha_publicacion(rs.getString("fecha_publicacion"));
                libro.setTomo(rs.getInt("tomo"));
                libro.setEdicion(rs.getString("edicion"));
                libro.setPaginas(rs.getInt("paginas"));
                libro.setEstado(rs.getString("estado"));
                lista.add(libro);
            }
            System.out.println("consulta realizada correctamente" + lista);
            return lista;
        } catch (Exception e) {
            System.out.println("Error en consulta por codigo en LibroAO. " + e.getMessage());
            return null;
        }
    }

    public boolean eliminar(int id_libro) {
        try {
            String sql = "delete from libros where id_libro=?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id_libro);
            int row = ps.executeUpdate();
            System.out.println("Registro eliminado");
            return true;
        } catch (Exception e) {
            System.out.println("No se pudo eliminar registro");
        }
        return false;
    }

    public boolean actualizar(Libros libro) {
        try {
            String sql = "update libro set id_editorial, id_genero=?, nombre=?, fecha_publicacion=?, tomo=?, edicion=?, paginas=?, estado=? where id_libro=?;";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, libro.getId_editorial());
            ps.setInt(2, libro.getId_genero());
            ps.setString(3, libro.getNombre());
            ps.setString(4, libro.getFecha_publicacion());
            ps.setInt(5, libro.getTomo());
            ps.setString(6, libro.getEdicion());
            ps.setInt(7, libro.getPaginas());
            ps.setString(8, libro.getEstado());
            ps.setInt(9, libro.getId_libro());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println(" actualizado");
            return true;
        } catch (Exception e) {
            System.out.println("No se pudo actualizar");

        }
        return false;
    }
}
