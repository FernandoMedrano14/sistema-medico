/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.Autores_librosDAO;
import DAO.DBConnection;
import Modelo.Autores_libros;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class Autores_librosController extends HttpServlet {

 protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            String accion = request.getParameter("action");
            switch (accion) {
                case "registrar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {

        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            int id_autor_libro = Integer.parseInt(request.getParameter("id_autor_libro"));
            int id_autor = Integer.parseInt(request.getParameter("id_autor"));
            int id_libro = Integer.parseInt(request.getParameter("id_libro"));

            Autores_libros autores = new Autores_libros(0);
            autores.setId_autor_libro((id_autor_libro));
            autores.setId_autor((id_autor));
            autores.setId_libro((id_libro));

            DBConnection conn = new DBConnection();
            Autores_librosDAO dao = new Autores_librosDAO(conn);
            String mensaje;
            boolean respuesta = dao.registrar(autores);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            rd = request.getRequestDispatcher("/registro.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error " + e);
        }

    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            Autores_librosDAO dao = new Autores_librosDAO(conn);
            List<Autores_libros> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consulta.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error consultar: controller: " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id_autor_libro = request.getParameter("id_autor_libro");

        try {
            DBConnection conn = new DBConnection();
            Autores_librosDAO dao = new Autores_librosDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id_autor_libro));
            List<Autores_libros> lista = dao.consultar();
            String mensaje = "";
            
            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";
            }
            
            RequestDispatcher rd;
            request.setAttribute("mensaje", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consulta.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String mensaje = "";
        try {
            DBConnection conn = new DBConnection();

            Autores_librosDAO dao = new Autores_librosDAO(conn);
            Autores_libros autores = new Autores_libros(Integer.parseInt("id_autor_libro"));
            autores.setId_autor(Integer.parseInt(request.getParameter("id_autor")));
            autores.setId_libro(Integer.parseInt(request.getParameter("id_libro")));
            

            if (dao.actualizar(autores)) {
                mensaje = "Se actualizó con exito";
            }
        } catch (Exception e) {
            mensaje = "Error en controller" + e;
        }

    }

    
    public String getServletInfo() {
        return "Short description";
    }

}
