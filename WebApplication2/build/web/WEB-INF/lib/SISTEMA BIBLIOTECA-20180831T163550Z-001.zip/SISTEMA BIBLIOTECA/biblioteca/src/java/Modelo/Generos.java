
package Modelo;

public class Generos {
    
    private int id;
    private String genero;

    public Generos(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Generos{" + "id=" + id + ", genero=" + genero + '}';
    }
    
    
    
}
