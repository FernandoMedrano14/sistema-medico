/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DBConnection;
import DAO.UsuarioDAO;
import Modelo.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Java's Setup
 */
public class UsuarioController extends HttpServlet {

     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        System.out.println("ESTOY EN EL SWITCH");
        switch (action) {
            case "ingresar":
                this.insertar(request, response);
                break;

            case "consultar":
                this.consultar(request, response);
                break;

            case "consultarporID":
                this.consultabyid(request, response, request.getParameter("id"));
                break;

            case "eliminar":
                this.eliminar(request, response, request.getParameter("id"));
                break;

            case "actualizar":
                this.actualizar(request, response);
                break;

            case "entrar":
                this.entrar(request, response);
                break;
                
            default:
                break;
        }
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void insertar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("estoy en insertar");
        try {
            String usuario = request.getParameter("usuario");
            String correo = request.getParameter("correo");
            String contra = request.getParameter("contra");
            String genero = request.getParameter("genero");
            

            Usuario user = new Usuario(0);
            user.setUsuario(usuario);
            user.setCorreo(correo);
            user.setContra(contra);
            user.setGenero(genero);

            DBConnection conn = new DBConnection();
            UsuarioDAO usa = new UsuarioDAO(conn);
            String mensaje;
            boolean respuesta = usa.insert(user);
            List<Usuario> lista = usa.Consultar();
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo realizar registro";
            }
            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/insertarusuario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error en insertar en controller: " + e);
        }
    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            UsuarioDAO usa = new UsuarioDAO(conn);
            List<Usuario> lista = usa.Consultar();
            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarusuario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error consultar usuario controller "+e);
        }

    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response, String id)
            throws ServletException, IOException {
        try {
            DBConnection conn = new DBConnection();
            UsuarioDAO usa = new UsuarioDAO(conn);

            boolean respuesta = usa.eliminar(Integer.parseInt(id));
            String mensaje;
            if (respuesta) {
                mensaje = "registro eliminado";
            } else {
                mensaje = "registro no eliminado";
            }
            List<Usuario> lista = usa.Consultar();
            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/consultarusuario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {

        }

    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String mensaje;
        DBConnection conn = new DBConnection();
        UsuarioDAO usa = new UsuarioDAO(conn);

        Usuario usua = new Usuario(Integer.parseInt(request.getParameter("id")));
        usua.setUsuario(request.getParameter("usuario"));
        usua.setCorreo(request.getParameter("correo"));
        usua.setContra(request.getParameter("contra"));
        usua.setGenero(request.getParameter("genero"));

        boolean respuesta = usa.actualizar(usua);
        if (respuesta) {
            mensaje = "se actualizo con exito";
        } else {
            mensaje = "no se pudo actualizar";
        }

        RequestDispatcher rd;
        request.setAttribute("respuesta", mensaje);
        rd = request.getRequestDispatcher("usuarios?action=consultar");
        rd.forward(request, response);
    }

    protected void consultabyid(HttpServletRequest request, HttpServletResponse response, String id)
            throws ServletException, IOException {
        try {
            DBConnection conn = new DBConnection();
            UsuarioDAO usa = new UsuarioDAO(conn);
            Usuario usua = usa.consultarporID(Integer.parseInt(request.getParameter("id")));
            RequestDispatcher rd;
            request.setAttribute("usua", usua);
            rd = request.getRequestDispatcher("/modificarusuario.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error" + e);
        }

    }
    
    protected void entrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String usuario = request.getParameter("usuario");
        String contra = request.getParameter("contra");
        String msg ,pagina; 
        try {
            DBConnection conn = new DBConnection();
            UsuarioDAO usa = new UsuarioDAO(conn);
            List<Usuario>lista = usa.entrar(usuario, contra);
            if(lista.size()>0){
                
                msg="Bienvenido "+usuario;
                pagina="/pag.jsp";
            }else{
                
                msg="usuario y contraseña incorrecta";
                pagina="/login.jsp";
            }
            
            RequestDispatcher rd;
            request.setAttribute("msg", msg);
            rd = request.getRequestDispatcher(pagina);
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error" + e);
        }

    }

}
