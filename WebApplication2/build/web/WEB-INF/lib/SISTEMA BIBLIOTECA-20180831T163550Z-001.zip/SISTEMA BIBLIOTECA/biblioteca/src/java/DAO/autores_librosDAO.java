package DAO;

import Modelo.Autores_libros;
import Modelo.Generos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

public class Autores_librosDAO {

    DBConnection conn;

    public Autores_librosDAO(DBConnection conn) {
        this.conn = conn;
    }

    public boolean registrar(Autores_libros aut) {
        try {
            String sql = "insert into autores_libros values ?,?,?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, aut.getId_autor_libro());
            ps.setInt(2, aut.getId_autor());
            ps.setInt(3, aut.getId_libro());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Registrado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede registrar" + e);
        }
        return false;
    }

    public List<Autores_libros> consultar() {
        try {

            String sql = "select * from autores_libros";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Autores_libros> lista = new LinkedList();
            Autores_libros aut;
            while (rs.next()) {
                aut = new Autores_libros(rs.getInt("id_autor_libro"));
                aut.setId_autor(rs.getInt("id_autor"));
                aut.setId_libro(rs.getInt("id_libro"));
                lista.add(aut);
                return lista;
            }
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return null;
    }

    public boolean eliminar(int id_autor_libro) {
        try {
            String sql = "delete from autores_libros where id = ?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, id_autor_libro);
            int row = ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Se ha eliminado con exito");
            return true;
        } catch (Exception e) {
            System.out.println("No se puede eliminar registro");
        }
        return false;
    }

    public boolean actualizar(Autores_libros aut) {
        try {
            String sql = "update autores_libros set "
                    + "id_autor=?"
                    + "id_libro=?"
                    + "where id_autor_libro=?";
            PreparedStatement ps = conn.Conectar().prepareStatement(sql);
            ps.setInt(1, aut.getId_autor_libro());
            ps.setInt(2, aut.getId_autor());
            ps.setInt(3, aut.getId_libro());
            ps.executeUpdate();
            conn.Desconectar();
            System.out.println("Actualizado con exito");
            return true;
        } catch (Exception e) {

        }
        return false;
    }

}
