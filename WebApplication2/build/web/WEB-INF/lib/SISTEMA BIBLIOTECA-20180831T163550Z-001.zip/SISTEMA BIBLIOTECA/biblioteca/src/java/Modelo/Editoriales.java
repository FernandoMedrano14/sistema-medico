
package Modelo;

public class Editoriales {
    
    private int id;
    private String nombre;
    private String direccion;
    private String pais;
    private String telefono;

    public Editoriales(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Editoriales{" + "id=" + id + ", nombre=" + nombre + ", direccion=" + direccion + ", pais=" + pais + ", telefono=" + telefono + '}';
    }
    
    
    
}
