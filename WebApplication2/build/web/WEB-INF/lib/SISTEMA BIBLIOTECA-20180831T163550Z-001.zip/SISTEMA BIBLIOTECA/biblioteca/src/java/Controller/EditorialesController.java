/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DBConnection;
import DAO.EditorialesDAO;
import Modelo.Editoriales;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class EditorialesController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
   
        try {

            String action = request.getParameter("action");
            switch (action) {
                case "ingresar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;

                case "consultarporID":
                    this.consultarporID(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            System.out.println("error" + e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.processRequest(request, response);
    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String nombre = request.getParameter("nombre");
            String direccion = request.getParameter("direccion");
            String pais = request.getParameter("pais");
            String telefono = request.getParameter("telefono");

            Editoriales editorial = new Editoriales(0);
            editorial.setNombre(nombre);
            editorial.setDireccion(direccion);
            editorial.setPais(pais);
            editorial.setTelefono(telefono);

            DBConnection conn = new DBConnection();
            EditorialesDAO edi = new EditorialesDAO(conn);
            String mensaje;
            boolean respuesta = edi.registrar(editorial);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/insertareditoriales.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error en controller" + e);
        }

    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            EditorialesDAO dao = new EditorialesDAO(conn);
            List<Editoriales> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultareditoriales.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id_autor = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            EditorialesDAO dao = new EditorialesDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id_autor));
            List<Editoriales> lista = dao.consultar();
            String mensaje = "";

            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";

            }
            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultareditoriales.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String mensaje = "";
        String id = request.getParameter("id");
        String nombre = request.getParameter("nombre");
        String direccion = request.getParameter("direccion");
        String pais = request.getParameter("pais");
        String telefono = request.getParameter("telefono");
        try {

            DBConnection conn = new DBConnection();
            EditorialesDAO dao = new EditorialesDAO(conn);
            Editoriales editorial = new Editoriales(0);
            List<Editoriales> lista = dao.consultar();

            editorial.setNombre(nombre);
            editorial.setDireccion(direccion);
            editorial.setPais(pais);
            editorial.setTelefono(telefono);
            editorial.setId(Integer.parseInt(id));

            boolean respuesta = dao.actualizar(editorial);
            if (respuesta) {
                mensaje = "Se actualizó con exito";
            }
            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/consultareditoriales.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            mensaje = "Error controller" + e;
        }

    }

    protected void consultarporID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            DBConnection conn = new DBConnection();
            EditorialesDAO dao = new EditorialesDAO(conn);
            List<Editoriales> lista = dao.ConsultarPorCod_Autor(Integer.parseInt(id));

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/modificareditoriales.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error en consulta por id " + e);
        }
    }
    
}
