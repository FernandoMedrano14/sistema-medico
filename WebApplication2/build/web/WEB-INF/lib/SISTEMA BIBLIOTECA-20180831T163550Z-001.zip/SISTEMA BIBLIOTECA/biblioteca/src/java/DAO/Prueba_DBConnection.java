
package DAO;

public class Prueba_DBConnection {
    
    public static void main(String[] args) {
        
        DBConnection conn = new DBConnection();
    }
    
}
