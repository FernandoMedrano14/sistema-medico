/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.AutoresDAO;
import DAO.DBConnection;
import Modelo.Autores;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Admin106
 */
public class AutoresController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            String action = request.getParameter("action");
            switch (action) {
                case "ingresar":
                    this.registrar(request, response);
                    break;
                case "consultar":
                    this.consultar(request, response);
                    break;
                case "eliminar":
                    this.eliminar(request, response);
                    break;
                case "actualizar":
                    this.actualizar(request, response);
                    break;

                case "consultarporID":
                    this.consultarporID(request, response);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            System.out.println("error" + e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.processRequest(request, response);
    }

    protected void registrar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            String nombre = request.getParameter("nombre");
            String fecha_nacimiento = request.getParameter("fecha_nacimiento");
            String nacionalidad = request.getParameter("nacionalidad");

            Autores autores = new Autores(0);
            autores.setNombre(nombre);
            autores.setFecha_nacimiento(fecha_nacimiento);
            autores.setNacionalidad(nacionalidad);

            DBConnection conn = new DBConnection();
            AutoresDAO dao = new AutoresDAO(conn);
            String mensaje;
            boolean respuesta = dao.registrar(autores);
            if (respuesta) {
                mensaje = "registro hecho con exito";
            } else {
                mensaje = "no se pudo guardar registro";
            }

            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/insertarAutor.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("error " + e);
        }

    }

    protected void consultar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            DBConnection conn = new DBConnection();
            AutoresDAO dao = new AutoresDAO(conn);
            List<Autores> lista = dao.consultar();

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consultarautor.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

    protected void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id_autor = request.getParameter("id_autor");

        try {
            DBConnection conn = new DBConnection();
            AutoresDAO dao = new AutoresDAO(conn);
            boolean respuesta = dao.eliminar(Integer.parseInt(id_autor));
            List<Autores> lista = dao.consultar();
            String mensaje = "";

            if (respuesta) {
                mensaje = "Se eliminó con exito";
            } else {
                mensaje = "error";

            }
            RequestDispatcher rd;
            request.setAttribute("respuesta", mensaje);
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/consulta.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    protected void actualizar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String mensaje = "";
        String id_autor = request.getParameter("id_autor");
        String nombre = request.getParameter("nombre");
        String fecha_nacimiento = request.getParameter("fecha_nacimiento");
        String nacionalidad = request.getParameter("nacionalidad");
        try {

            DBConnection conn = new DBConnection();
            AutoresDAO dao = new AutoresDAO(conn);
            Autores autores = new Autores(0);
            List<Autores> lista = dao.consultar();

            autores.setNombre(nombre);
            autores.setFecha_nacimiento(fecha_nacimiento);
            autores.setNacionalidad(nacionalidad);
            autores.setId_autor(Integer.parseInt(id_autor));

            boolean respuesta = dao.actualizar(autores);
            if (respuesta) {
                mensaje = "Se actualizó con exito";
            }

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            request.setAttribute("respuesta", mensaje);
            rd = request.getRequestDispatcher("/consultarautor.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            mensaje = "Error al actualizar" + e;
        }

    }

    protected void consultarporID(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id_autor = request.getParameter("id_autor");

        try {
            DBConnection conn = new DBConnection();
            AutoresDAO dao = new AutoresDAO(conn);
            List<Autores> lista = dao.ConsultarPorCod_Autor(Integer.parseInt(id_autor));

            RequestDispatcher rd;
            request.setAttribute("lista", lista);
            rd = request.getRequestDispatcher("/modificarAutor.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            System.out.println("Error " + e);
        }
    }

}
